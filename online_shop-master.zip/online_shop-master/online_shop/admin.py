from django.contrib import admin

from online_shop.models import Product, Category

# Register your models here.

admin.site.register(Product)
admin.site.register(Category)
